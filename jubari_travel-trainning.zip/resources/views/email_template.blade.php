<div class="row">
<div class="col-md-6 col-sm-12 ">
<img width="100%" height="100%" src="{{asset('assets/img/logo.png')}}">
</div>
<div class="col-md-6 col-sm-12 ">
<p>Hello,  <b>{{ $emails['NAME'] }}</b></p>
<p>SYSTEM ACCOUNT INFO:</p>
<p>EMAIL:{{ $emails['EMAIL'] }}.</p>
<p>PASSWORD:'{{ $emails['PASSWORD'] }}''</p>
<p>THANKS</p>
</div>
</div>