<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Sup_CurrencyController extends Controller
{
    //
}
