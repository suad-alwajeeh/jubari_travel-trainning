<footer class="main-footer">
    <div class="float-right d-none d-sm-block col-12 text-center">
      
    
    <strong class="">Copyright &copy;   <a href="">Jubari.Travel</a>.</strong> All rights reserved.
    </div></footer>
