@extends('app_layouts.master')
@section('main_content')
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    @if (session('seccess'))
    <div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert">×</button>
        {{ session('seccess') }}
    </div>
    @elseif(session('failed'))
    <div class="alert alert-danger" role="alert">
        <button type="button" class="close" data-dismiss="alert">×</button>
        {{ session('failed') }}
    </div>
    @endif
    <section class="content-header bg-white">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> Ticket Service</h1>
                </div>
                              
<div class="col-6">
            <ol class="breadcrumb float-sm-right bg-white">
              <li class="breadcrumb-item"><a href="/service/show_ticket/1"> Ticket</a></li>
              <li class="breadcrumb-item active">Sent Ticket Services</li>

            </ol>
  </div>
  </br>
  </br>
                <div class="col-sm-6">

                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->

    <!-- /.content -->

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">

                <div class="col-sm-6">

                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title col-3  d-inline-block">TICKET</h3>
                                <a class="btn btn-outline-primary so_form_btn" href="/service/ticket"> <i
                                        class="fa fa-plus" aria-hidden="true"></i> Add New Service</a>

                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                                <table id="datatable"
                                    class="table table-responsive  table-hover text-nowrap text-center">


                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Type</th>
                                            <th>Issue Date </th>
                                            <th> Refernce </th>
                                            <th>Passenger Name</th>
                                            <th>Airline Code</th>
                                            <th>Ticket Number </th>
                                            <th>Dept City </th>
                                            <th> Dept Date </th>
                                            <th> Arr City </th>
                                            <th>Dept City2 </th>
                                            <th> Dept Date2 </th>
                                            <th> Arr City2 </th>
                                            <th>Busher Time</th>
                                            <th>Supplier</th>
                                            <th>Supplier Cost</th>
                                            <th>Supplier Cuurency</th>
                                            <th>Passenger Cost </th>
                                            <th>Passenger Currency </th>
                                            <th>Ticket Status </th>
                                            <th>Remark</th>
                                        </tr>
                                    </thead>
                                    <tbody class="row2">
                                        <?php $i=1 ?>

                                        @forelse($ticket as $tickets)

                                        <tr>


                                            <input type="hidden" class="delete_id" value="{{$tickets->tecket_id}}">
                                            <td>
                                                <?php echo $i;?>
                                            </td>
                                            @if($tickets->Dep_city2==null)
                                            <td> One Way</td>
                                            @else
                                            <td> Rounded Way</td>
                                            @endif

                                            <td>{{$tickets->Issue_date }}</td>
                                            <td> {{$tickets->refernce}} </td>
                                            <td>{{$tickets->passenger_name}}</td>
                                            <td>{{$tickets->ticket}}</td>
                                            <td>{{$tickets->ticket_number}} </td>
                                            <td>{{$tickets->Dep_city}} </td>
                                            <td> {{$tickets->dep_date}} </td>
                                            <td> {{$tickets->arr_city}} </td>
                                            @if($tickets->Dep_city2==null)
                                            <td>--</td>
                                            @else
                                            <td> {{$tickets->Dep_city2}} </td>
                                            @endif
                                            @if($tickets->dep_date2==null)
                                            <td>--</td>
                                            @else
                                            <td> {{$tickets->dep_date2}} </td>
                                            @endif
                                            @if($tickets->arr_city2==null)
                                            <td>--</td>
                                            @else
                                            <td> {{$tickets->arr_city2}} </td>
                                            @endif
                                            @if($tickets->bursher_time==null)
                                            <td>--</td>
                                            @else
                                            <td> {{$tickets->bursher_time}} </td>
                                            @endif
                                            <td>{{$tickets->supplier_name}} </td>
                                            <td>{{$tickets->provider_cost}} </td>
                                            <td>{{$tickets->cur_name}}</td>
                                            <td>{{$tickets->cost}} </td>
                                            <td> {{$tickets->passnger_currency}} </td>
                                            @if($tickets->ses_status==1)
                                            <td>OK</td>
                                            @elseif($tickets->ses_status==2)
                                            <td>Issue</td>
                                            @elseif($tickets->ses_status==3)
                                            <td>Void</td>
                                            @elseif($tickets->ses_status==4)
                                            <td>Refund</td>
                                            @endif
                                            <td>{{$tickets->remark}} </td>


                                            </td>
                                        </tr>

                                    </tbody>
                                    <?php $i++ ?>

                                    @empty
                                    <tr>
                                        <td colspan="10">There is No data Pleas Add Service
                                        <td>
                                    </tr>
                                    @endforelse

                                    <tfoot>

                                        <tr>

                                        </tr>

                                    </tfoot>
                                </table>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                        {{$ticket->links()}}
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
        </div>
    </section>
</div>
@endsection